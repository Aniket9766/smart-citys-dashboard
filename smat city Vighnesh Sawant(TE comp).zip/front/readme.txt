step 1-open index1 files with any browser
step2- use any username and password and click on submit button
step3- the you will get enter to the smart city dashboard
